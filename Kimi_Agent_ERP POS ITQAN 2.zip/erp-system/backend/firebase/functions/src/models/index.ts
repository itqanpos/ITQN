// User Models
export * from './User';

// Product Models
export * from './Product';

// Sale Models
export * from './Sale';

// Customer Models
export * from './Customer';

// Inventory Models
export * from './Inventory';

// Company Models
export * from './Company';

// POS Models
export * from './POSSession';

// Sales Visit Models
export * from './SalesVisit';

// Supplier Model
export interface Supplier {
  id: string;
  companyId: string;
  
  name: string;
  contactName?: string;
  
  email?: string;
  phone: string;
  phone2?: string;
  fax?: string;
  
  address?: {
    street: string;
    city: string;
    state?: string;
    postalCode?: string;
    country: string;
  };
  
  taxNumber?: string;
  commercialRegistration?: string;
  
  paymentTerms?: number;
  creditLimit?: number;
  currentBalance: number;
  
  categories?: string[];
  
  notes?: string;
  
  isActive: boolean;
  
  totalOrders: number;
  totalPurchases: number;
  
  createdAt: Date;
  updatedAt: Date;
}

// Purchase Order Model
export interface PurchaseOrder {
  id: string;
  orderNumber: string;
  companyId: string;
  branchId: string;
  
  supplierId: string;
  supplierName: string;
  
  items: PurchaseOrderItem[];
  
  subtotal: number;
  discountAmount: number;
  taxAmount: number;
  shippingCost: number;
  total: number;
  
  status: PurchaseOrderStatus;
  
  orderDate: Date;
  expectedDate?: Date;
  receivedDate?: Date;
  
  notes?: string;
  
  createdBy: string;
  createdByName: string;
  
  createdAt: Date;
  updatedAt: Date;
}

export interface PurchaseOrderItem {
  id: string;
  productId?: string;
  productName: string;
  description?: string;
  
  quantity: number;
  receivedQuantity?: number;
  
  unitPrice: number;
  total: number;
  
  notes?: string;
}

export type PurchaseOrderStatus = 'draft' | 'sent' | 'confirmed' | 'partial' | 'received' | 'cancelled';

// Expense Model
export interface Expense {
  id: string;
  expenseNumber: string;
  companyId: string;
  branchId: string;
  
  categoryId: string;
  categoryName: string;
  
  amount: number;
  currency: string;
  
  description: string;
  
  date: Date;
  
  paymentMethod: string;
  reference?: string;
  
  receiptUrl?: string;
  
  notes?: string;
  
  isRecurring: boolean;
  recurringFrequency?: 'daily' | 'weekly' | 'monthly' | 'yearly';
  
  createdBy: string;
  createdByName: string;
  
  createdAt: Date;
  updatedAt: Date;
}

// Expense Category
export interface ExpenseCategory {
  id: string;
  companyId: string;
  
  name: string;
  description?: string;
  
  color?: string;
  icon?: string;
  
  budget?: number;
  
  isActive: boolean;
  
  createdAt: Date;
  updatedAt: Date;
}

// Notification Model
export interface Notification {
  id: string;
  userId: string;
  companyId: string;
  
  type: NotificationType;
  title: string;
  message: string;
  
  data?: {
    [key: string]: any;
  };
  
  isRead: boolean;
  readAt?: Date;
  
  actionUrl?: string;
  
  createdAt: Date;
}

export type NotificationType = 
  | 'info' 
  | 'success' 
  | 'warning' 
  | 'error' 
  | 'sale' 
  | 'inventory' 
  | 'payment' 
  | 'system';

// Audit Log Model
export interface AuditLog {
  id: string;
  companyId: string;
  
  userId: string;
  userName: string;
  userEmail: string;
  
  action: string;
  resource: string;
  resourceId: string;
  
  oldData?: any;
  newData?: any;
  
  ipAddress?: string;
  userAgent?: string;
  
  createdAt: Date;
}

// Dashboard Stats
export interface DashboardStats {
  sales: {
    today: number;
    thisWeek: number;
    thisMonth: number;
    lastMonth: number;
    growth: number;
  };
  orders: {
    today: number;
    thisWeek: number;
    thisMonth: number;
    pending: number;
  };
  customers: {
    total: number;
    newThisMonth: number;
    active: number;
  };
  inventory: {
    totalProducts: number;
    lowStock: number;
    outOfStock: number;
    totalValue: number;
  };
  receivables: {
    total: number;
    overdue: number;
    thisMonth: number;
  };
}

// Report Models
export interface SalesReport {
  period: {
    start: Date;
    end: Date;
  };
  summary: {
    totalSales: number;
    totalAmount: number;
    totalCost: number;
    grossProfit: number;
    grossMargin: number;
    totalItems: number;
    averageOrderValue: number;
  };
  byDay: {
    date: string;
    sales: number;
    amount: number;
  }[];
  byProduct: {
    productId: string;
    productName: string;
    quantity: number;
    amount: number;
    cost: number;
    profit: number;
  }[];
  byCategory: {
    categoryId: string;
    categoryName: string;
    amount: number;
    percentage: number;
  }[];
  bySalesRep: {
    salesRepId: string;
    salesRepName: string;
    sales: number;
    amount: number;
  }[];
  byPaymentMethod: {
    method: string;
    amount: number;
    count: number;
  }[];
}
