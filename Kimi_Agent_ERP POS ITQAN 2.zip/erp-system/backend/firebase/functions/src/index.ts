import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as express from 'express';
import * as cors from 'cors';

// Initialize Firebase Admin
admin.initializeApp();

// Import routes
import { authRoutes } from './routes/auth';
import { userRoutes } from './routes/users';
import { productRoutes } from './routes/products';
import { categoryRoutes } from './routes/categories';
import { customerRoutes } from './routes/customers';
import { supplierRoutes } from './routes/suppliers';
import { saleRoutes } from './routes/sales';
import { inventoryRoutes } from './routes/inventory';
import { purchaseOrderRoutes } from './routes/purchaseOrders';
import { expenseRoutes } from './routes/expenses';
import { reportRoutes } from './routes/reports';
import { posRoutes } from './routes/pos';
import { branchRoutes } from './routes/branches';
import { salesVisitRoutes } from './routes/salesVisits';
import { dashboardRoutes } from './routes/dashboard';
import { notificationRoutes } from './routes/notifications';
import { settingRoutes } from './routes/settings';
import { companyRoutes } from './routes/companies';

// Create Express app
const app = express();

// CORS configuration
const corsOptions: cors.CorsOptions = {
  origin: [
    'http://localhost:3000',
    'http://localhost:5173',
    'https://your-erp-domain.com'
  ],
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Company-ID'],
  credentials: true,
  optionsSuccessStatus: 200
};

app.use(cors(corsOptions));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging middleware
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/products', productRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/suppliers', supplierRoutes);
app.use('/api/sales', saleRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/purchase-orders', purchaseOrderRoutes);
app.use('/api/expenses', expenseRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/pos', posRoutes);
app.use('/api/branches', branchRoutes);
app.use('/api/sales-visits', salesVisitRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/settings', settingRoutes);
app.use('/api/companies', companyRoutes);

// Error handling middleware
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Error:', err);
  
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      message: 'Validation Error',
      errors: err.details || err.message
    });
  }
  
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      success: false,
      message: 'Unauthorized'
    });
  }
  
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route ${req.path} not found`
  });
});

// Export the Express app as a Cloud Function
export const api = functions.https.onRequest(app);

// Scheduled functions
export const dailyReportGeneration = functions.pubsub
  .schedule('0 1 * * *')
  .timeZone('Asia/Riyadh')
  .onRun(async (context) => {
    console.log('Running daily report generation...');
    // Implementation in services/reportsService
  });

export const lowStockAlert = functions.pubsub
  .schedule('0 9 * * *')
  .timeZone('Asia/Riyadh')
  .onRun(async (context) => {
    console.log('Checking low stock items...');
    // Implementation in services/inventoryService
  });

// Firestore triggers
export const onSaleCreated = functions.firestore
  .document('sales/{saleId}')
  .onCreate(async (snap, context) => {
    const sale = snap.data();
    console.log('New sale created:', context.params.saleId);
    
    // Update inventory
    // Create audit log
    // Send notifications
  });

export const onInventoryChanged = functions.firestore
  .document('inventory/{inventoryId}')
  .onUpdate(async (change, context) => {
    const before = change.before.data();
    const after = change.after.data();
    
    if (after.quantity <= after.minQuantity) {
      console.log('Low stock alert for:', after.productId);
      // Send low stock notification
    }
  });

export const onUserCreated = functions.auth
  .user()
  .onCreate(async (user) => {
    console.log('New user created:', user.uid);
    
    // Create user document in Firestore
    await admin.firestore().collection('users').doc(user.uid).set({
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      status: 'active',
      role: 'pending'
    });
  });

// Callable functions
export const generateInvoicePDF = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  }
  
  const { saleId } = data;
  // Generate PDF logic
  return { success: true, downloadUrl: '...' };
});

export const processRefund = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  }
  
  const { saleId, reason } = data;
  // Process refund logic
  return { success: true };
});
